package SemanticExceptions;

public class BadYearException extends Exception{

    public BadYearException() {
        super();
    }
}
