package SemanticExceptions;

public class BadPriceException extends Exception{

    public BadPriceException() {
        super();
    }
}
