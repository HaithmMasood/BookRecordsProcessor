package SemanticExceptions;

public class BadIsbn13Exception extends Exception{

    public BadIsbn13Exception() {
        super();
    }
}
