package SemanticExceptions;

public class BadIsbn10Exception extends Exception {

    public BadIsbn10Exception() {
        super();
    }
}
