package SyntaxExceptions;

public class MissingFieldException extends Exception {
    public MissingFieldException() {
        super();
    }
}
