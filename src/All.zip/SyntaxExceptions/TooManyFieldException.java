package SyntaxExceptions;

public class TooManyFieldException extends Exception{
    public TooManyFieldException() {
        super();
    }
}