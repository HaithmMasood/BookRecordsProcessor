package SyntaxExceptions;

public class UnknownGenreException extends Exception{
    public UnknownGenreException() {
        super();
    }
}
