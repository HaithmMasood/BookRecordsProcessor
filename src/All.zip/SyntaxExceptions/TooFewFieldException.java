package SyntaxExceptions;

public class TooFewFieldException extends Exception {
    public TooFewFieldException() {
        super();
    }
}
